﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CustomerLib;

namespace CloneDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer[] customerList = new Customer[5];
            for(int i=0;i<5;i++)
            {
                customerList[i] = new Customer();
                customerList[i].CustomerId = new Random().Next(100).ToString();
                Console.WriteLine("Enter Name");
                customerList[i].Name = Console.ReadLine();
                Console.WriteLine("Enter Address");
                customerList[i].Address = Console.ReadLine();
            }
            Array.Sort(customerList,new CustomerSorting());
            foreach(Customer customer in customerList)
            {
                Console.WriteLine("Customer Id={0}\tName={1}",customer.CustomerId,customer.Name);

            }

            //Customer customer = new Customer();
            //customer.CustomerId = "42568";
            //customer.Name = "Ashok";
            //customer.Address = "Chennai";
            //Customer copy_customer =(Customer) customer.Clone();
            //customer.CustomerId = "42578";
            //Console.WriteLine(copy_customer.CustomerId);
            //Console.WriteLine(copy_customer.Name);
            //Console.WriteLine(copy_customer.Address);
            Console.ReadKey();

        }
    }
}
