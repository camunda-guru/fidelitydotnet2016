﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace EventsDemo
{
    delegate void TimerDelegate();
    class EventCreator
    {
        public event TimerDelegate TimerEvent;

        public void Subscribe()
        {
            while(true)
            {
                Thread.Sleep(2000);
                if (TimerEvent != null)
                    TimerEvent();
            }
        }
    }
}
