﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            EventCreator ec = new EventCreator();
            ec.TimerEvent  += new TimerDelegate(new BackupManager().Backup);
            ec.Subscribe();
            Console.ReadKey();
        }
    }
}
