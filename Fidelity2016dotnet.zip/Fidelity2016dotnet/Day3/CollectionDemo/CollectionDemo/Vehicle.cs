﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionDemo
{
    class Vehicle:IComparable
    {
        public String RegNo { get; set; }
        public String Model { get; set; }
        public String Make { get; set; }
        public DateTime DOR { get; set; }

        public int CompareTo(object obj)
        {
            Vehicle v = (Vehicle)obj;
            return this.RegNo.CompareTo(v.RegNo);
        }
    }
}
