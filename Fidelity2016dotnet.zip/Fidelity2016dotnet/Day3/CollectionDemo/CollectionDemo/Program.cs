﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace CollectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
          
            Queue queue = new Queue();
            queue.Enqueue(new Customer { CustomerId = 357, Name = "Ashok" });
            queue.Enqueue(new Customer { CustomerId = 367, Name = "Anoop" });
            queue.Enqueue(new Customer { CustomerId = 389, Name = "Subha" });
            queue.Enqueue(new Customer { CustomerId = 373, Name = "Dany" });
            queue.Enqueue(new Customer { CustomerId = 390, Name = "Siva" });

            
            int pos = -1;
            Customer cust = null;
            Console.WriteLine("Enter Customer Id to find serving time");
            int id = Convert.ToInt32(Console.ReadLine());
            
            Object[] objarray = queue.ToArray();
            while(queue.Count>0)
            {
                cust =(Customer) queue.Dequeue();
                if (cust.CustomerId == id)
                    pos = Array.IndexOf(objarray, cust);
            }

            if (pos >= 0)
                Console.WriteLine("Customer will be served after{0} minutes", (pos + 1) * 2);
            else
                Console.WriteLine("No Matching record found");

            //Stack stack = new Stack();
            //Console.WriteLine("Enter Decimal Number");
            //int number = Convert.ToInt32(Console.ReadLine());
            //int quo, rem = 0;
            //while(number>0)
            //{
            //    rem = number % 2;
            //    stack.Push(rem);
            //    quo = number / 2;
            //    number = quo;
            //}
            //while(stack.Count>0)
            //{
            //    Console.Write(stack.Pop());
            //}


            //List<Question> questionList = new List<Question>();
            //questionList.Add(new Question { QuestionId=1,QuestionText="Is C# functional Programming Language?"});
            //questionList.Add(new Question { QuestionId =2, QuestionText = "Is Demonetization good for economy?" });
            //questionList.Add(new Question { QuestionId =3, QuestionText = "will India become super power in 2020?" });
            //questionList.Add(new Question { QuestionId =4, QuestionText = "Is dotnet framework suitable for ios?" });
            //BitArray correctAns = new BitArray(new Boolean[]{false,true,true,false});
            //BitArray userAns = new BitArray(4, true);
            //String answer = null;
            //int pos=0;
            //foreach(Question question in questionList)
            //{
            //    Console.WriteLine("Q.{0}\t{1}", question.QuestionId, question.QuestionText);
            //    Console.WriteLine("Enter True(T) or False(F) as Answer");
            //    answer = Console.ReadLine();
            //    if (answer.Equals("T"))
            //        userAns.Set(pos, true);
            //    else
            //        userAns.Set(pos, false);
            //    pos++;
            //}
            ////find the score
            //BitArray result = correctAns.Xor(userAns);
            //int count = 0;
            //foreach(Boolean data in result)
            //{
               
            //    if (!data)
            //        count++;
            //}
            //Console.WriteLine("Score={0}", count);


            //List<Vehicle> vehicleList = new List<Vehicle>();
            //vehicleList.Add(new Vehicle { RegNo = "TN-02-0646", Make = "Honda", Model = "Ivtec", DOR = new DateTime(2016, 4, 27) });
            //vehicleList.Add(new Vehicle { RegNo = "DL-02-0646", Make = "Maruti", Model = "Estilo", DOR = new DateTime(2016, 4, 27) });
            //vehicleList.Add(new Vehicle { RegNo = "CH-02-0646", Make = "Tata", Model = "Safari", DOR = new DateTime(2016, 4, 27) });
            //vehicleList.Add(new Vehicle { RegNo = "HR-02-0646", Make = "Nissan", Model = "Renault", DOR = new DateTime(2016, 4, 27) });
            //vehicleList.Add(new Vehicle { RegNo = "UP-02-0646", Make = "BMW", Model = "d3", DOR = new DateTime(2016, 4, 27) });

            ////sort them by reg no
            //vehicleList.Sort();
            //foreach(Vehicle v in vehicleList)
            //{
            //    Console.WriteLine("RegNo={0}\tModel={1}\tMake={2}",v.RegNo,v.Model,v.Make);
                

            //}



           // ArrayList arrayList = new ArrayList();
            //arrayList.Add(2485743);
            //arrayList.Add("Fidelity");
            //arrayList.Add(5.6f);
            //arrayList.Add(true);
            //arrayList.Add(359.546);
            //arrayList.Add('c');
            //arrayList.Add(new Vehicle { RegNo = "TN-02-0646", Make = "Honda", Model = "Ivtec", DOR = new DateTime(2016, 4, 27) });
            //IEnumerator ienum = arrayList.GetEnumerator();
            //while(ienum.MoveNext())
            //{
            //    if(ienum.Current is Vehicle)
            //    {
            //        Vehicle v = (Vehicle)ienum.Current;
            //        Console.WriteLine(v.RegNo);
            //        Console.WriteLine(v.Model);
            //        Console.WriteLine(v.Make);

            //    }
            //    else
            //     Console.WriteLine(ienum.Current);
            //}
            Console.ReadKey();
        }
    }
}
