﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
   //define delegate
    delegate String LanguageDelegate(String word);
    class Program
    {
        static void Main(string[] args)
        {
            Translator trans = new Translator();          

            //instantiate delegate
            LanguageDelegate ld = new LanguageDelegate(trans.EngToTamil);
            //Asynchronous delegate
            IAsyncResult result = ld.BeginInvoke("Hello", UpdateDashBoard, ld);
            while (!result.IsCompleted)
                Console.WriteLine("Waiting for the result...");

           String response= ld.EndInvoke(result);
           Console.WriteLine(response);




            //ld += new LanguageDelegate(trans.EngToHindi);
            //ld += new LanguageDelegate(trans.EngToTelugu);
            ////invoke the delegate

            //foreach(LanguageDelegate ld1 in ld.GetInvocationList())
            //{
            //    Console.WriteLine(ld1("Hello"));
            //    Console.WriteLine(ld1("Good Morning"));
            //}



            //for (int i = 0; i < 2;i++ )
            //{
            //    Console.WriteLine("Enter the Word");
            //    ld(Console.ReadLine());
            //}
                Console.ReadKey();
        }

        public static void UpdateDashBoard(IAsyncResult result)
        {
            Console.WriteLine("Dash Board is ready with latest info");
        }

    }
}
