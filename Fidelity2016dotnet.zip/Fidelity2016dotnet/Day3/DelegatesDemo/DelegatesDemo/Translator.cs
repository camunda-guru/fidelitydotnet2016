﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    class Translator
    {
        private Dictionary<String, String> tamil;
        private Dictionary<String, String> hindi;
        private Dictionary<String, String> telugu;
        private String result;

        public Translator()
        {
            tamil = new Dictionary<string, string>();
            hindi = new Dictionary<string, string>();
            telugu = new Dictionary<string, string>();
            TamilDictionary();
            HindiDictionary();
            TeluguDictionary();
        }
        public void TamilDictionary()
        {
            tamil.Add("Hello", "Vanakkam");
            tamil.Add("Good Morning", "kalai Vankkam");
        }

        public void HindiDictionary()
        {
            hindi.Add("Hello", "Namasthe");
            hindi.Add("Good Morning", "Suprabath");
        }

        public void TeluguDictionary()
        {
            telugu.Add("Hello", "Namaskaram");
            telugu.Add("Good Morning", "Suprabhatham");
        }
        public String EngToTamil(String word)
        {
           
            if(tamil.ContainsKey(word))
            {
                //Console.WriteLine(tamil[word]);
                result = tamil[word];
            }
            return result;
        }
        public String EngToHindi(String word)
        {
           
            if (hindi.ContainsKey(word))
            {
                //Console.WriteLine(hindi[word]);
                result = hindi[word];
            }
            return result;
        }
        public String EngToTelugu(String word)
        {
          
            if (hindi.ContainsKey(word))
            {
               // Console.WriteLine(telugu[word]);
                result = telugu[word];
            }
            return result;
        }

    }
}
