﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            NameValueCollection nc = new NameValueCollection();
            nc.Add("A+", "95");
            nc.Add("A+", "96");
            nc.Add("A+", "97");
            nc.Add("A", "90");
            nc.Add("A", "86");
            nc.Add("B", "72");
            String[] result=null;
            foreach(String key in nc.Keys)
            {
                Console.WriteLine(key);
                result= nc.GetValues(key);
                foreach(String data in result)
                {
                    Console.Write(data + "\t");
                }
                Console.WriteLine();
            }

            //SortedList<Member, String> memberList = new SortedList<Member, string>();
            //memberList.Add(new Member { MemberId = 1, Name = "Harshita" }, "Gold");
            //memberList.Add(new Member { MemberId = 21, Name = "Shivani" }, "Silver");
            //memberList.Add(new Member { MemberId =32, Name = "Kavya" }, "Platinum");
            //memberList.Add(new Member { MemberId = 4, Name = "Hemanth" }, "Gold");
            //foreach (Member key in memberList.Keys)
            //   Console.WriteLine("Id={0}\t Status={1}", key.Name, memberList[key]);


            //SortedList<int, String> traineeList = new SortedList<int, string>();
            //traineeList.Add(3957, "Amit");
            //traineeList.Add(122, "Anoop");
            //traineeList.Add(907, "Bala");
            //traineeList.Add(3967, "Suman");
            //traineeList.Add(2, "Rekha");
            //foreach (int key in traineeList.Keys)
            //    Console.WriteLine("Id={0}\t Name={1}", key, traineeList[key]);




            //Console.WriteLine("Enter Amount in words");
            //String data = Console.ReadLine();
            //String[] dataArray = data.Split(' ');
            //foreach (String word in dataArray)
            //{
                
            //    foreach (DictionaryEntry entry in NumToWord.getWords())
            //    {

            //        if (entry.Value.Equals(word))
            //        {
            //            Console.Write(entry.Key);
            //            break;
            //        }


            //    }

            //}




            //Console.WriteLine("Enter Number");
            //int number = Convert.ToInt32(Console.ReadLine());
            //int quo=0, rem = 0;
            //Stack stack = new Stack();
            //while(number>0)
            //{
            //    rem = number % 10;
            //    if(NumToWord.getWords().Contains(rem))
            //    {
            //        stack.Push(NumToWord.getWords()[rem]);
            //    }
            //    quo = number / 10;
            //    number = quo;
            //}
            //while (stack.Count > 0)
            //    Console.Write(stack.Pop()+"\t");
            Console.ReadKey();

        }
    }
}
