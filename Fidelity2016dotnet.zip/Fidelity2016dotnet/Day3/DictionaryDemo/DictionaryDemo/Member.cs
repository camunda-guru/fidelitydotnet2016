﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryDemo
{
    class Member:IComparable
    {
        public int MemberId { get; set; }
        public String Name { get; set; }

        public int CompareTo(object obj)
        {
            return this.Name.CompareTo(((Member)obj).Name);
        }
    }
}
