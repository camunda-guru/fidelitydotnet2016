﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilderDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            StringBuilder sbldr = new StringBuilder();
            sbldr.Append("Fidelity");
            Console.WriteLine(sbldr.ToString());
            sbldr.Append("Gurgaon");
            Console.WriteLine(sbldr.ToString());
            char[] charArray = { 'F', 'i', 'D', 'E', 'L', 'I', 'T', 'Y' };
           
            String s =new String(charArray,0,charArray.Length);
            Console.WriteLine(s);
            s = s + "Gurgaon";
            Console.WriteLine(s);
            
            //Stopwatch
            Stopwatch timer = new Stopwatch();
            String data = String.Empty;
            timer.Start();

            for (int i = 0; i < 10000;i++ )
            {
                data += i;
            }
            timer.Stop();
            Console.WriteLine("StopWatch Time taken={0}", timer.ElapsedMilliseconds);
            timer.Reset();
            StringBuilder sdata = new StringBuilder();

            timer.Start();
            for (int i = 0; i < 10000; i++)
            {
                sdata.Append(i);
            }
            timer.Stop();
            Console.WriteLine("StopWatch Time taken={0}", timer.ElapsedMilliseconds);
                Console.ReadKey();
        }
    }
}
