﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
namespace RegularExpressionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            String pattern = "^[0-9]{5}$";
            Random rand = new Random();
            long genData = 0;
            for(int i=0;i<10;i++)
            {
                genData = rand.Next(99999);
                if(Regex.IsMatch(genData.ToString(),pattern))
                   Console.WriteLine("Match found ={0}",genData);
                
                else
                    Console.WriteLine("No Match found={0}",genData);
            }
            String apattern = "^[A-Za-z]+$";
            Console.WriteLine("Enter Name");
            String name = Console.ReadLine();
            if (Regex.IsMatch(name, apattern))
                Console.WriteLine("Valid Name");
            else
                Console.WriteLine("Invalid Name");
            String phonePattern = "^\\d{2}[-]?\\d{10}$";
            Console.WriteLine("Enter Mobile No");
            String PhoneNumber = Console.ReadLine();
            if (Regex.IsMatch(PhoneNumber,phonePattern))
                Console.WriteLine("Valid Phone Number");
            else
                Console.WriteLine("Invalid Phone Number");
            Console.ReadKey();
        }
    }
}
