﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Base class library
using System.Threading;
using System.Globalization;
using Microsoft.VisualBasic;

namespace BankingAppln
{
    class CustomerInfo
    {
        static void TestRange()
        {
            int hexdata = 0xfc;
            Console.WriteLine(hexdata);
            int number = 5;
            Console.WriteLine("Binary Value of {0} ={1}", number,Convert.ToString(number,2));
            float roi = 0.75f;
            decimal irt = 0.78m;
            
            char alphabet = '\u0048';
            Console.WriteLine(alphabet);


        }


        static void Main(string[] args)
        {
            //verbatim
            String path = @"G:\Local Disk\csc examples\DateTimeconstructor";
            String quote=@"I am 
                             always try CancellationToken be IReadOnlyCollection";

            //Customer customer = new Customer 
            //{ Name="Ashok,",
            //    Gender=GenderType.Male,DOB=new DateTime(1990,2,2)};
            //Console.WriteLine("Date of Birth={0}", customer.DOB);
            //long year = DateAndTime.DateDiff(DateInterval.Year, 
            //  customer.DOB,  DateTime.Today);
            //Console.WriteLine("Age={0}", year);




            //Customer customer = new Customer();
            //customer.Gender = GenderType.Male;
            //Console.WriteLine("Gender={0}", customer.Gender);//getter called
            //Vehicle vehicle = new Vehicle();
            //vehicle.fuel = FuelType.Diesel;



            //TestRange();
            ////local variables
            //String name = null;
            //int age = 0;
            //Console.WriteLine("Enter Name");
            //name = Console.ReadLine();
            //Console.WriteLine("Enter Age");
            //age = Convert.ToInt32(Console.ReadLine());
            //Console.WriteLine("Hi!{0} is your age{1}?Confirm", name,age);

            //char[] data = name.ToCharArray();
            ////enhanced for loop
            //foreach(char letter in data)
            //{
            //    Thread.Sleep(1000);
            //    Console.Write(letter + "\t");
            //}
            
            Console.ReadKey();


        }
    }
}
