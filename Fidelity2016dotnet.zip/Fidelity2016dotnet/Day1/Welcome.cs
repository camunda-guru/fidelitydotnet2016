using System;

class Account
{

    public static void Main()
	{

            Console.WriteLine("Welcome Intermediate Batch from Account");      

	}


}
class Transaction
{

    public static void Main()
	{

            Console.WriteLine("Welcome Intermediate Batch from transaction");      

	}


}

