﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RandomNumbers
{
    class Program
    {

        static void Main(string[] args)
        {
            Random rand = new Random();
            int[] randArray = new int[100];
            //store the random numbers
            for(int i=0;i<randArray.Length;i++)
            {
                randArray[i] = rand.Next(1000);
            }
            Console.WriteLine("before sorting.....");
            foreach (int num in randArray)
                Console.Write(num + "\t");
            Console.WriteLine("After sorting.....");
            Array.Sort(randArray);
            foreach (int num in randArray)
                Console.Write(num + "\t");
            Array.Reverse(randArray);
            Console.WriteLine("After Reversing.....");
            foreach (int num in randArray)
                Console.Write(num + "\t");
            String[] names = { "Shyam", "Subha", "David", "Anu", "Joseph", "Kamala" };
            Console.WriteLine("before sorting.....");
            foreach (String name in names)
                Console.Write(name + "\t");
            Console.WriteLine("After sorting.....\n");
            Array.Sort(names);           
            foreach (String name in names)
                Console.Write(name + "\t");
            Console.ReadKey();


        }
    }
}
