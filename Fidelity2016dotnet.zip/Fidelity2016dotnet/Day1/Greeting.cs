using System;
public class Greeting
{

   public String Wish(String name)
   {

       return "Many more happy returns of the day!\t"+name;

   }


}
