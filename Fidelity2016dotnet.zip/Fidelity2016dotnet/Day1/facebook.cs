using System;
class FaceBook
{

public static void Main()
{
    Greeting greeting =new Greeting();
     
    Console.WriteLine(greeting.Wish("Vignesh"));            



}


}