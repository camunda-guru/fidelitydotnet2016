﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace ThreadDemo
{
    class Policy
    {
        public void PolicyRules(Object number)
        {
            Thread.CurrentThread.Name = number.ToString();           
            try
            {
               Monitor.Enter(this);
                Console.WriteLine("Thread={0}",Thread.CurrentThread.Name);
                for (int i = 0; i < Convert.ToInt32(number); i++)
                    Console.WriteLine(i);
            }
            finally
            {
               Monitor.Exit(this);

            }

                //Console.WriteLine("Thread Name={0},Third Party Injury Not Covered.....", Thread.CurrentThread.Name);
        }

    }
}
