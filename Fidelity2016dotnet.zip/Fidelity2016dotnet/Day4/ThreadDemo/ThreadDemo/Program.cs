﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
namespace ThreadDemo
{
    class Program
    {
        static void Main(string[] args)
        {

            ParameterizedThreadStart ts = new ParameterizedThreadStart(new Policy().PolicyRules);
            Thread thread1 = new Thread(ts);
            Thread thread2 = new Thread(ts);
            Thread thread3= new Thread(ts);
            Thread thread4 = new Thread(ts);
            Thread thread5 = new Thread(ts);
            thread1.Start(6);          
            thread2.Start(7);
            thread3.Start(5);
            thread4.Start(4);
            thread5.Start(3);
          
            //Thread.CurrentThread.Name = "Main";
           // Console.WriteLine(Thread.CurrentThread.Name);
            //int number = Process.GetCurrentProcess().Threads.Count;
            //Console.WriteLine("Number of Threads{0}", number);
      
            Console.ReadKey();
        }
    }
}
