﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace TaskDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int number=4;
            Task<String> task = new Task<String>
                (() => new WordConverter().getWord(number));
            task.Start();
            Console.WriteLine("Word{0} Equal to Number{1}", 
                task.Result, number);

            Dictionary<int, String> response = 
                new WordConverter().InvokeResponse().Result;

            foreach(int key in response.Keys)
            {
                Console.WriteLine(key);
            }

            Console.ReadKey();
        }
    }
}
