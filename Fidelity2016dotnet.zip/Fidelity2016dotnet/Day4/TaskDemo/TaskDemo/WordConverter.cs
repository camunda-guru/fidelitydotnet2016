﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskDemo
{
    class WordConverter
    {
        private Dictionary<int, String> dict;
        public WordConverter()
        {
            dict = new Dictionary<int, string>();
            dict.Add(1, "one");
            dict.Add(2, "two");
            dict.Add(3, "three");
            dict.Add(4, "four");
            dict.Add(5, "five");
        }

        public String getWord(Object number)
        {
            String response=null;
            if (dict.ContainsKey(Convert.ToInt32(number)))
                response = dict[Convert.ToInt32(number)];
            return response;
        }

        public async Task<Dictionary<int,String>> InvokeResponse()
        {
            Task<Dictionary<int,String>> task = getDictionary();
            Dictionary<int,String> response = await task;
            return response;
        }


        public async Task<Dictionary<int,String>> getDictionary()
        {
            return dict;
        }


    }
}
