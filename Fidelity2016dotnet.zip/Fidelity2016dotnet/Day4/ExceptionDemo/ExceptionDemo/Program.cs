﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo
{
    class Program
    {

        static void TestArgument(String data)
        {
            try
            {
                Console.WriteLine(data.IndexOf('T'));
            }
            catch(NullReferenceException n)
            {
                //ArgumentException args = 
                   // new ArgumentException
                    //    ("Wrong Argument with null Value{0}",n);
                throw new ArgumentException("Wrong Argument with null Value{0}", n);
                     

            }
        }



        static void ExceptionHandling(String[] args)
        {

            
            
            int num = 100, k = 0;
            Console.WriteLine("Enter K value");
           
            try
            {
                //Console.WriteLine(args[9]);
                k = Convert.ToInt32(Console.ReadLine());
                num = num / k;

                Console.WriteLine("Number={0}", num);

            }
            catch(DivideByZeroException div)
            {
                Console.WriteLine(div.Message);
                Console.WriteLine(div.Source);
                Console.WriteLine(div.StackTrace);
                Console.WriteLine(div.TargetSite);
                throw new Exception("Divide by Zero");
            }
            catch(FormatException f)
            {
                Console.WriteLine(f.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
             finally
            {
                Console.WriteLine("Code Executed....");
            }


            



        }




        static void Main(string[] args)
        {

            Console.WriteLine("Enter Age");
            int age = Convert.ToInt32(Console.ReadLine());
            Customer customer = new Customer();
            try
            {
                customer.Age = age;
            }
            catch(Exception agex)
            {
                Console.WriteLine(agex.Message);
            }


            try
            {
                TestArgument(null);
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine(ex.Message);
            }

            try
            {
                ExceptionHandling(args);
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            try
            {
                Console.WriteLine(args[2]);
            }
            catch(IndexOutOfRangeException inx)
            {
                Console.WriteLine(inx.Message);
            }
            Console.ReadKey();

        }
    }
}
