﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectedArchDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            foreach(String key in DataManager.getData().Keys)
            {
                Console.WriteLine("RegNo={0},Insured Amount={1}", 
                    key, DataManager.getData()[key]);
            }
            Console.ReadKey();
        }
    }
}
