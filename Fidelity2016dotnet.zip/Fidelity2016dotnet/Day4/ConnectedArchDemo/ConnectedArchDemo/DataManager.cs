﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Collections;
namespace ConnectedArchDemo
{
    class DataManager
    {
        private static SqlConnection conn;
        private static SqlCommand cmd;
        private static SqlDataReader dr;
       
        static SqlConnection getConnection()
        {
          String connString = ConfigurationManager.ConnectionStrings
              ["FidelityDBConn"].ConnectionString.ToString();

          return new SqlConnection(connString);
        }

        public static Hashtable  getData()
        {
            conn = getConnection();
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandText = @"select v.RegNo,p.InsuredAmount from 
            Vehicle v, Policy p where v.vehicleId=p.vehicleId";
            dr= cmd.ExecuteReader();
            //DataTable dt = new DataTable();
           // dt.Load(dr);
            Hashtable ht = new Hashtable();
            while(dr.Read())
            {
                ht.Add(dr[0], dr[1]);
            }
            return ht;
        }

    }
}
