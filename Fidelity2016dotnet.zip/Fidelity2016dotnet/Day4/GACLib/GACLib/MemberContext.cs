﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GACLib
{
   public class MemberContext
    {
       private List<Member> memberList;
       public MemberContext()
       {
           memberList = new List<Member>();

       }

       public List<Member> getList()
       {
           memberList.Add(new Member { MemberId=1,Name="Ashok"});
           memberList.Add(new Member { MemberId = 2, Name = "Arjun" });
           memberList.Add(new Member { MemberId = 44, Name = "Meena" });
           memberList.Add(new Member { MemberId = 5, Name = "Mahesh" });
           memberList.Add(new Member { MemberId = 788, Name = "Swathi" });
           return memberList;
       }
    }
}
