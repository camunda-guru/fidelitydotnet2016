﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] Names = { "Parmeswari", "Bala", "Banu","Vignesh","Vimala","Preethi", "Sara", "Shamili" };

            var gresponse= from n in Names

                           group n by n[0] into r
                           select new { FirstLetter = r.Key, Name = r };
            foreach (var k in gresponse)
            {
                Console.WriteLine
                    ("Names that start with letter '{0}' :", k.FirstLetter);
                foreach (var w in k.Name)
                {
                    Console.WriteLine(w);
                }
            }




            var response = from n in Names
                           orderby n
                           select n;
            Console.WriteLine("Order By");
            foreach (String name in response)
                Console.WriteLine(name);

            Console.WriteLine("--------");
            var data = from n in Names
                       where n.Length > 4
                       select n;
            foreach (String name in data)
                Console.WriteLine(name);

            int[] numbers = { 5879, 3567, 43, 22, 56, 9, 12, 56, 75, 46 };
            var ndata = from n in numbers
                       where n % 2 == 0
                       select n;
            foreach (int number in ndata)
                Console.WriteLine(number);

            ////pair of values
            //int[] array1 = { 0, 3, 5, 6, 7, 8 };
            int[] array2 = { 5, 6, 8, 9, 12, 14, 16 };

            //var result = from n1 in array1
            //             from n2 in array2
            //             where n1 < n2
            //             select new { n1, n2 };
            //foreach (var x in result)
            //    Console.WriteLine("{0}-->{1}",x.n1, x.n2);
             //Fetch first five values
            Console.WriteLine("Fetch first three values");
            var result1 = array2.Take(3);
            foreach (int x in result1)
                Console.WriteLine(x);
            Console.WriteLine("Fetch last three values");
            var result2 = array2.Skip(4);
            foreach (int x in result2)
                Console.WriteLine(x);



            var employeeSorting = from emp in new DataContext().getEmployeeList()
                                  orderby emp.Name
                                  select new { emp.EmployeeId, emp.Name };


            foreach (var emp in employeeSorting)
                Console.WriteLine("{0}=>{1}", emp.EmployeeId,emp.Name);

            //join query

            var qresponse = from emp in new DataContext().getEmployeeList()
                    join proj in new DataContext().getProjectList() on emp.ProjectId equals proj.ProjectId
                    select new { ename=emp.Name,pname=proj.Name };

            foreach (var q in qresponse)
                Console.WriteLine("{0}=>{1}", q.ename,q.pname);

            Console.ReadKey();

        }
    }
}
