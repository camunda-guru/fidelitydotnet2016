﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQDemo
{
    class DataContext
    {

        public List<Project> getProjectList()
        {
            List<Project> projectList = new List<Project>();
            projectList.Add(new Project { ProjectId = 1, Name = "Axis" });
            projectList.Add(new Project { ProjectId = 2, Name = "HSBC" });
            projectList.Add(new Project { ProjectId = 3, Name = "HDFC" });
            projectList.Add(new Project { ProjectId = 4, Name = "SBI" });
            return projectList;
        }

        public List<Employee> getEmployeeList()
            {
                List<Employee> employeeList = new List<Employee>();
               
                employeeList.Add(new Employee { EmployeeId = 23432, Name = "Anubhav", Address = "Chennai", ProjectId = 1 });
                employeeList.Add(new Employee { EmployeeId = 23454, Name = "Bhuvana", Address = "Bangalore", ProjectId = 2 });
                employeeList.Add(new Employee { EmployeeId = 23467, Name = "Shyam", Address = "Delhi", ProjectId = 3 });
                employeeList.Add(new Employee { EmployeeId = 23478, Name = "Johny", Address = "Pune", ProjectId = 1 });
                employeeList.Add(new Employee { EmployeeId = 23420, Name = "Shammy", Address = "Mumbai", ProjectId = 4 });
                employeeList.Add(new Employee { EmployeeId = 23499, Name = "Zhara", Address = "Chennai", ProjectId = 3 });

                return employeeList;
            }
    }
}
