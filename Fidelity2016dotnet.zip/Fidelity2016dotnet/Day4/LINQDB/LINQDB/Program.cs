﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace LINQDB
{
    class Program
    {
        static void Main(string[] args)
        {
            FiedelityDataDataContext db = new FiedelityDataDataContext();
            var data = from v in db.Vehicles
                       join p in db.Policies on v.VehicleId equals p.VehicleId
                       select new { v.RegNo, p.PolicyId };
            foreach (var result in data)
                Console.WriteLine("{0}=>{1}", result.RegNo, result.PolicyId);

            XDocument xdoc = XDocument.Load("F:\\Fidelity2016dotnet\\Day4\\LINQDB\\LINQDB\\ProductData.xml");

            var query = from p in xdoc.Descendants("Product")
                        select new
                        {
                            Id = p.Element("Id").Value,
                            Name = p.Element("Name").Value,
                            Cost = p.Element("Cost").Value
                        };

            foreach(var q in query)
            {
                Console.WriteLine("{0}=>{1}=>{2}", q.Id, q.Name, q.Cost);
            }

            Console.ReadKey();
        }
    }
}
