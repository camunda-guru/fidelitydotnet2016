﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MethodOverLodingDemo
{
    class Program
    {
        public static void Add(byte x,short y)
        {
            Console.WriteLine("Calling Byte and Short{0}",x + y);
        }
        public static void Add(short x, byte y)
        {
            Console.WriteLine("Calling Short and Byte{0}", x + y);
        }
        public static void Add(long x, long y)
        {
            Console.WriteLine("Calling Long and Long{0}", x + y);
        }
        public static void Add(float x, float y)
        {
            Console.WriteLine("Calling Float{0}",x + y);
        }
        public static void Add(double x, double y)
        {
            Console.WriteLine("Calling Double{0}", x + y);
        }
        static void Main(string[] args)
        {
            //Add(5, 6);
            Console.ReadKey();
        }
    }
}
