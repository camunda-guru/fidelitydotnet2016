﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChainOfConstructors
{
    class Customer
    {
        private int customerId;
        private String name;
        public Customer():this(5)
        {

        }
        public Customer(int id,String n)
        {
            customerId = id;
            name = n;
        }
        public Customer(int id):this(id,"default")
        {
            customerId = id;
           
        }
        public override string ToString()
        {
            return "CustomerId="+customerId+"\t"+"Name="+name;
        }
        
    }
}
