﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChainOfConstructors
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomerData customerData = new CustomerData();
            Random rand = new Random();

            for(int i=0;i<5;i++)
            {
                Console.WriteLine("Enter Customer Name");
                //indexer set method
                customerData[i] = new Customer(rand.Next(100),
                    Console.ReadLine());
            }
            //Display the data
            for(int i=0;i<5;i++)
            {
                //indexer get method
                Customer c = customerData[i];
                Console.WriteLine(c);

            }
            Console.ReadKey();
        }
    }
}
