﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChainOfConstructors
{
    class CustomerData
    {
        private Customer[] customerArray;
        public CustomerData()
        {
            customerArray = new Customer[5];

        }
        //indexer
        public Customer  this[int pos]
        {
            get
            {
                return customerArray[pos];
            }
            set
            {
                customerArray[pos] = value;
            }
        }

    }
}
