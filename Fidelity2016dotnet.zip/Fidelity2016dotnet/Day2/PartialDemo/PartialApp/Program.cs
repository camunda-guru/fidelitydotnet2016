﻿using PartialDemo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Transaction tran= new Transaction(1, 43795, 
                new DateTime(2016, 1, 1));
            Console.WriteLine(tran);
            Console.ReadKey();
        }
    }
}
