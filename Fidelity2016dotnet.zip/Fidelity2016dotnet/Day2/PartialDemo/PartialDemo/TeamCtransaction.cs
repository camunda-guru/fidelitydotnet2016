﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialDemo
{
    partial class Transaction
    {
        public Transaction()
        {

        }
        public Transaction(int id,int amount, DateTime date)
        {
            tranId = id;
            transactionAmount = amount;
            tranDate = date;
        }
    }
}
