﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialDemo
{
    public partial class Transaction
    {
        private int tranId;
        private long transactionAmount;
        private DateTime tranDate;

    }
}
