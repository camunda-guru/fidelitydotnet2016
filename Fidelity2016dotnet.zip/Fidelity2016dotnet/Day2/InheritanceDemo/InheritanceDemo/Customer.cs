﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Customer
    {
        static Customer()
        {
            Console.WriteLine("Base class static constructor called...");
        }

        public Customer()
        {
            Console.WriteLine("Base class construtor called.....");

        }
    }
}
