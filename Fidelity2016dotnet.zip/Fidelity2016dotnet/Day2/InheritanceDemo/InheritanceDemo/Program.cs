﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //PermanentEmployee pobj = new PermanentEmployee("427567", "Ashok", "Chennai", 43756, 3254, 4353, 0.12f);
            //Console.WriteLine(pobj.EmployeeNo);
            //Console.WriteLine(pobj.Name);
            //Console.WriteLine(pobj.Address);
            //Console.WriteLine(pobj.BasicSalary);

            //runtime polymorphism
            //method overriding
            //Employee employee = new PermanentEmployee("427567", "Ashok", "Chennai", 43756, 3254, 4353, 0.12f);
            //Console.WriteLine(employee);


            //GoldCustomer goldCustomer = new GoldCustomer();

            Employee employee = new PermanentEmployee(43756, 3254, 4353, 0.12f);
            employee.EmployeeNo = "43856874";
            employee.Name = "Ashok";
            employee.Address = "Chennai";
            Console.WriteLine(employee.EmployeeNo);
            Console.WriteLine(employee.Name);
            Console.WriteLine(employee.Address);
            Console.WriteLine(employee);



            Console.ReadKey();
        }
    }
}
