﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class GoldCustomer:Customer
    {
        static GoldCustomer()
        {
            Console.WriteLine("Static Gold Customer Called....");
        }
        public GoldCustomer()
        {
            Console.WriteLine("Gold Customer Called....");
        }
    }
}
