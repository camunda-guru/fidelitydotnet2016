﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    interface Employee
    {

        String EmployeeNo { get; set; }
        String Name { get; set; }
        String Address { get; set; }

        //protected String employeeNo;
        //protected String name;
        //protected String address;
        //public Employee()
        //{

        //}
        //public Employee(String no, String n, String addr)
        //{
        //    employeeNo = no;
        //    name = n;
        //    address = addr;
        //}

         float Payment();
        

        //public override string ToString()
        //{
        //    return "EmployeeNo=\t" + employeeNo + "\nName=\t" + name + "\nAddress=\t" + address;
        //}
    }
}
