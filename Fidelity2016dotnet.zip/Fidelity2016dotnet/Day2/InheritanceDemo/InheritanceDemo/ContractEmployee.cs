﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class ContractEmployee
    {
        private int wage;
        private int days;
        public ContractEmployee()
        {

        }
        public ContractEmployee(int wage,int days)
        {
           
            this.wage = wage;
            this.days = days;

        }

        public  float Payment()
        {
            throw new NotImplementedException();
        }
    }
}
