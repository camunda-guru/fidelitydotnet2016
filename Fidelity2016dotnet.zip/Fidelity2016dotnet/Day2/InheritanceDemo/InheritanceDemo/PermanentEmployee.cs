﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceDemo
{
    class PermanentEmployee:Employee
    {
        private String employeeNo;
        private String name;
        private String address;
        private int basicSalary,da,hra;
        private float pf;

        public PermanentEmployee()
        {

        }
        public PermanentEmployee(int bsal, int da,int hra,float pf)
        {
            
            basicSalary = bsal;
            this.da = da;
            this.hra = hra;
            this.pf = pf;

        }

        public String EmployeeNo
        {
            get
            {
                return employeeNo;
            }
            set
            {
                employeeNo = value;
            }
        }
        public String Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
        public String Address
        {
            get
            {
                return address;
            }
            set
            {
                address = value;
            }
        }
        public int BasicSalary
        {
            get
            {
                return basicSalary;
            }
        }

        public float Payment()
        {
            return basicSalary + da + hra - (basicSalary * pf);
        }

        public override string ToString()
        {
             return "\n Basic Salary=\t"+basicSalary+"\nNet Salary"+Payment();
             
        }
    }
}
