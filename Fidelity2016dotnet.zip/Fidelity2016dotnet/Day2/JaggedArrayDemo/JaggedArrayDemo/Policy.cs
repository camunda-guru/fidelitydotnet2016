﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrayDemo
{
    class Policy
    {
        public int PolicyNo { get; set; }
        public String PolicyHolderName { get; set; }
        public String Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public long AmountInsured { get; set; }
    }
}
