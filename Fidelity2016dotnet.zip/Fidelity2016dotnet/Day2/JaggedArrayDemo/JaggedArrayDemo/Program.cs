﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrayDemo
{
    class Program
    {
        static void JaggedArray()
        {
            int row, col;
            Console.WriteLine("Enter No of Customers");
            row = Convert.ToInt32(Console.ReadLine());
            int[][] customerData = new int[row][];
            //Number of columns
            for (int i = 0; i < customerData.Length; i++)
            {
                Console.WriteLine("Enter Premeium Type----(1,2,4,12)");
                col = Convert.ToInt32(Console.ReadLine());
                customerData[i] = new int[col];
            }
            //Read Premeium Amount for each customer
            String message = null;
            for (int i = 0; i < customerData.Length; i++)
            {
                message = null;
                Console.WriteLine("Enter Premeium for Customer\t{0}", i);
                switch (customerData[i].Length)
                {
                    case 1: message = "Annual";
                        break;
                    case 2: message = "Bi Annual";
                        break;
                    case 4: message = "Quarterly";
                        break;
                    case 12: message = "Monthly";
                        break;
                }
                for (int j = 0; j < customerData[i].Length; j++)
                {

                    Console.WriteLine("Enter Premeium Amount for {0}{1}th period", message, j);
                    customerData[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }


            //display premeium information
            Console.WriteLine("Premeium Details Customer wise");
            for (int i = 0; i < customerData.Length; i++)
            {
                Console.WriteLine("\nCustomer ={0}", i);
                for (int j = 0; j < customerData[i].Length; j++)
                {
                    Console.Write(customerData[i][j] + "\t");
                }

            }

        }

        static void ConstDemo()
        {
            const float pivalue = 3.14f;
            float radius = 1.0f;
            //Console.WriteLine("Enter pivalue");
            //pivalue = Convert.ToSingle(Console.ReadLine());
            Console.WriteLine("Enter Radius");
            radius = Convert.ToSingle(Console.ReadLine());

            float perimeter= 2*pivalue*radius;
            Console.WriteLine("Permeter={0}", perimeter);

        }

        public static Vehicle VehicleInstance()
        {
            return new Vehicle { RegNo = "TN-02-0646", Model = "ivtec", 
                Make = "Honda", DOR = new DateTime(2016, 4, 27) };

        }

        public static Policy PolicyInstance()
        {
            return new Policy();
        }

        public static Object ChooseObject(int option)
        {
            Object obj = null;
            if (option == 1)
                obj= VehicleInstance();
            if (option == 2)
                obj= PolicyInstance();
            return obj;
        }

        static void UncheckedDemo()
        {
            byte number1 = 128;
            byte number2 = 130;
            byte number3 = unchecked((byte)(number1 + number2));
            Console.WriteLine(number3);
        }

        static void CheckedDemo()
        {
            byte number1 = 128;
            byte number2 = 130;
            try
            {
                byte number3 = checked((byte)(number1 + number2));
                Console.WriteLine(number3);
            }
            catch(OverflowException oexc)
            {
                Console.WriteLine(oexc.Message);
            }
            
        }

        static void AsOperatorDemo()
        {
            Object[] objArray = new Object[5];
            objArray[0] = 438756874;
            objArray[1] = "Welcome";
            objArray[2] = true;
            objArray[3] = 3.55f;
            objArray[4] = '\u0056';
            foreach(Object obj in objArray)
            {
                Console.WriteLine(obj.GetType());
                Type type = obj.GetType();
                //Console.WriteLine(type.ToString()); 
                switch(type.ToString())
                {
                    case "System.String":
                        Console.WriteLine(obj as String);
                        break;
                    case "System.Int32":
                        Console.WriteLine(obj as int?);
                        break;
                }
                //Console.WriteLine(obj as int?);
                //Console.WriteLine(obj as String);
                //Console.WriteLine(obj as float?);
                //Console.WriteLine(obj as bool?);
                //Console.WriteLine(obj as char?);

            }

        }



        static void Main(string[] args)
        {
            
            foreach(String data in args)
            {
                Console.WriteLine(data);
            }
            //Currency Format
            //Console.WriteLine("Amount in dollars={0:C}", 537695.00);
            //Console.WriteLine("Amount in exponential Form={0:E}", 5376959356936246798);
           // Console.WriteLine("Amount in HexaDecimal={0:X}", 15);

            
            //CheckedDemo();
            //Object obj =ChooseObject(2);
            //// is operator
            //if (obj is Policy)
            //    Console.WriteLine("It is Policy Instance");
            //if (obj is Vehicle)
            //    Console.WriteLine("It is Vehicle Instance"); 
            //// as operator
            //AsOperatorDemo();

            
            Console.ReadKey();



        }
    }
}
