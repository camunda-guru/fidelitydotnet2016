﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JaggedArrayDemo
{
    class Vehicle
    {
        public String RegNo { get; set; }
        public String Make { get; set; }
        public String Model { get; set; }
        public DateTime DOR { get; set; }
    }
}
