﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OperatorOverloadingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Complex c1 = new Complex { Real=7,Imaginary=5};
            Complex c2 = new Complex { Real = 12, Imaginary = 17 };
            Complex c3 = c1 + c2;
            Console.WriteLine("Real={0}\tImaginary={1}",c3.Real, c3.Imaginary);
            Console.ReadKey();

        }
    }
}
