﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterPassingDemo
{
    class Program
    {
        public static void ModifyParam(int x)
        {
            x = x + 25;
        }
        public static void CallByRef(ref int x)
        {
            x = x + 25;
        }
        public static void OutDemo(int value1,int value2, out int value3,out int value4)
        {
            value3 = value1 + value2;
            value4 = value1 - value2;
        }
        public static void OptionalDemo(String username,String password="welcome")
        {
            Console.WriteLine(username);
            Console.WriteLine(password);
        }
        public static void NamedParamsdemo(int weight, float height, String name)
        {
            Console.WriteLine(name);
            Console.WriteLine(weight);
            Console.WriteLine(height);
        }

        public static void FlexiParams(String ipaddress, String serverName, params String[] users)
        {
            Console.WriteLine(ipaddress);
            Console.WriteLine(serverName);
            foreach (String user in users)
                Console.WriteLine(user);
        }

        static void Main(string[] args)
        {
            //int x = 8;
            //int y = 10;
            //int result1, result2;
            ////ModifyParam(x);
            ////CallByRef(ref x);
            //OutDemo(x, y, out result1, out result2);
            //Console.WriteLine(result1);
            //Console.WriteLine(result2);
            ////Console.WriteLine(x);
            //OptionalDemo("sa");
            //NamedParamsdemo( 70,name: "Param", height: 5.6f);
            FlexiParams("172.16.8.102", "sa","Anu","Seema","Joy");
            FlexiParams("172.16.8.102", "sa", "Anu", "Seema");
            FlexiParams("172.16.8.102", "sa", "Anu", "Seema", "Joy","Shobha");
            FlexiParams("172.16.8.102", "sa", "Anu", "Seema", "Joy","Shalini","Ajith");
            Console.ReadKey();

        }
    }
}
