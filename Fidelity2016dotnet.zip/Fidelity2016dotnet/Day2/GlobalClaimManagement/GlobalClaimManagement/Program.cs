﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalClaimDAL;
using GlobalClaimBL;
namespace GlobalClaimManagement
{
    class Program
    {
        static void Main(string[] args)
        {

            Vehicle vehicle = new Vehicle {RegNo="TN-32-0646",Model="ivtec",Make="Honda", DOR=new DateTime(2016,4,27) };
            VehicleBL vehicleBL = new VehicleBL();
            vehicleBL.AddVehicle(vehicle);
            vehicle = new Vehicle { RegNo = "TN-02BE-0678", Model = "estilo", Make = "Maruti", DOR = new DateTime(2009, 5, 29) };
            vehicleBL.AddVehicle(vehicle);
            //Display All the Vehicle Details
            foreach(Vehicle v in vehicleBL.GetVehicleList())
            {
                if (v != null)
                {
                    Console.WriteLine(v.RegNo);
                    Console.WriteLine(v.Make);
                    Console.WriteLine(v.Model);
                    Console.WriteLine(v.DOR);
                }
            }

            Console.ReadKey();

        }
    }
}
