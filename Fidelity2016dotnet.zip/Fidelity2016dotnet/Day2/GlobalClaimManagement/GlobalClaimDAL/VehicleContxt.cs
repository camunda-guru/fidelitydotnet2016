﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GlobalClaimDAL
{
    public class VehicleContxt
    {
        private Vehicle[] vehicleList;
        private static int pos;
        public VehicleContxt()
        {
            vehicleList = new Vehicle[3];
        }

        public void AddVehicle(Vehicle vehicle)
        {
            
            vehicleList[pos] = vehicle;
            pos++;
        }

        public Vehicle[] GetVehicleList()
        {
            return vehicleList;
        }

    }
}
