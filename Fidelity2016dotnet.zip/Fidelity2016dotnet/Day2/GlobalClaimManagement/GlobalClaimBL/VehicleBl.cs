﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalClaimDAL;
namespace GlobalClaimBL
{
    public class VehicleBL
    {
        private VehicleContxt vtx;
        public VehicleBL()
        {
            vtx = new VehicleContxt();
        }

        public void AddVehicle(Vehicle vehicle)
        {
            vtx.AddVehicle(vehicle);
        }
        public Vehicle[] GetVehicleList()
        {
            return vtx.GetVehicleList();
        }

        public Vehicle VehicleSearchByRegNo(String RegNo)
        {
            return null;
        }

    }
}
