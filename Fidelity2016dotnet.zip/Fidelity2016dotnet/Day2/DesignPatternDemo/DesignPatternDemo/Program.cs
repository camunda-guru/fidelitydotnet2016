﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ////Singleton and static demo
            Printer printer = Printer.GetPrinterInstance();
            Console.WriteLine("Single Object Created");
            try
            {
                Printer printer1 = Printer.GetPrinterInstance();
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();

        }
    }
}
