﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignPatternDemo
{
    class Printer
    {
        private static int count;

        private Printer()
        {
            count++;
        }

        public static Printer GetPrinterInstance()
        {
            if (count < 1)
                return new Printer();
            else
                throw new Exception("More than one instance cannot be created");

        }
    }
}
